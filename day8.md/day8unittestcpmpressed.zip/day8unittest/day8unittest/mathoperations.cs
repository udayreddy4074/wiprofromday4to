﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

  namespace day8unittest
{
    public class mathoperations
    {
        public virtual int Add(int a, int b)
        {
            return a + b;
        }
        public int Sub(int a, int b)
        {
            return a - b;
        }
        public int Mul(int a, int b)
        {
            return a * b;
        }
        public int Div(int a, int b)
        {
            return a / b;
        }
        public virtual bool CheckValues()
        {
            return false;
        }
        public int Muli(int a, int b)
        {
            return a * b;
        }



    }
    public class Employee
    {
        string name;
        int age;
        public Employee(string ename, int age)
        {
            name = ename;
            age = age;
        }
        public string st
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
    }
}

