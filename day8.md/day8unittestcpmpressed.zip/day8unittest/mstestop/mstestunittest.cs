﻿using System;
using day8unittest;

namespace mstestop
{
    [TestClass]
    public sealed class mstestunittest
    {
        [TestMethod]
        public void TestMethodadd()
        {
            mathoperations ms=new mathoperations();
            int res = ms.Add(20, 20);
            Assert.AreEqual(res,40);

        }
        [TestMethod]
        public void TestMethodmin()
        {
            mathoperations ms = new mathoperations();
            int res = ms.Sub(20, 20);
            Assert.AreEqual(res, 0);

        }
        [TestMethod]
        public void TestMethodmul()
        {
            mathoperations ms = new mathoperations();
            int res = ms.Mul(20, 20);
            Assert.AreEqual(res, 400);

        }
        [TestMethod]
        public void TestMethoddiv()
        {
            mathoperations ms=new mathoperations();
            int res = ms.Div(20, 20);
            Assert.AreEqual(res, 1);

        }


    }
}
