
    using Moq;
    using day8unittest;
    namespace nunittest
{
        public class Tests
        {
            public int i = 50, j = 10;
            public bool result;
            [SetUp]
            public void CheckNonNegative()
            {
                if (i > 0 && j > 0)
                {
                    result = true;
                }
                else
                {
                    result = false;
                }
            }
            [Test]
            public void TestAdd()
            {
                if (result)
                {
                mathoperations mop = new mathoperations();
                    int res = mop.Add(i, j);
                    Assert.AreEqual(60, res);
                }
                else
                {
                    Assert.Fail();
                }
            }
            [Test]
            [TestCase(100, 2, 50)]
            [TestCase(50, 2, 25)]
            public void TestDiv(int a, int b, int actual)
            {

            mathoperations mth = new mathoperations();
                int result = mth.Div(a, b);
                Assert.AreEqual(result, actual);
            }
            [Test]
            [Ignore("Not yet Implemented")]
            public void TestSub()
            {
            }
            [Test]
            [TestCase(100, 10, 1000)]
            public void TestPro(int a, int b, int act)
            {
            //Arrange
            mathoperations mh = new mathoperations();
                //Act
                int res = mh.Muli(a, b);
                //Assert
                Assert.AreEqual(act, res);
            }
            [Test]
            public void MockTest()
            {
                Mock<mathoperations> m = new Mock<mathoperations>();
                m.Setup(x => x.CheckValues()).Returns(true);
                Assert.AreEqual(true, m.Object.CheckValues());
            }
        }
    }
