namespace xunittest
{
    public class xUnitTest1
    {
        [Fact]
        public void Test1()
        {


        }
    }
}